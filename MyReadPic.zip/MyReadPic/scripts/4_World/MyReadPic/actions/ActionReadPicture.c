class ActionReadPicture: ActionSingleUseBase 

{ void ActionReadPicture() 
{ m_CommandUID = DayZPlayerConstants.CMD_ACTIONMOD_ITEM_ON; m_StanceMask = DayZPlayerConstants.STANCEMASK_ERECT | DayZPlayerConstants.STANCEMASK_CROUCH; }

override void CreateConditionComponents() 
{ m_ConditionItem = new CCINonRuined; m_ConditionTarget = new CCTNone; }

override string GetText() 
{ 
return "Прочитать"; 
}

override bool HasTarget() 
{ 
return false; // действие только на себя 
}

override bool 
ActionCondition(PlayerBase player, ActionTarget target, ItemBase item) 
{ // Показать действие только если предмет в руках 
if (!player || !item) return false; return item == player.GetItemInHands() && MyPicturePaper.Cast(item) != null; 
}

override void OnExecuteClient(ActionData action_data) 
{ if (!action_data) return; 
PlayerBase player = action_data.m_Player; if (!player) return;

ItemBase item = action_data.m_MainItem;
MyPicturePaper paper = MyPicturePaper.Cast(item);
if (!paper) return;

string img = paper.GetPicturePath();

// Открываем наше меню и передаем туда путь к картинке
UIManager uim = GetGame().GetUIManager();
uim.EnterScriptedMenu(MYREADPIC_MENU_ID, null);

UIScriptedMenu menu = uim.GetMenu();
PictureViewerMenu viewer = PictureViewerMenu.Cast(menu);
if (viewer)
{
  viewer.SetImage(img);
}
}
// На сервере ничего делать не нужно 
override void OnExecuteServer
(ActionData action_data) {} 
}