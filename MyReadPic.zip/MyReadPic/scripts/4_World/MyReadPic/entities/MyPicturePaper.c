class MyPicturePaper extends Paper 
{ // Путь к картинке, упакованной в мод 
string GetPicturePath() { return "MyReadPic/GUI/textures/MyReadPic/paper_image.edds"; }

override void SetActions() 
{ super.SetActions(); AddAction(ActionReadPicture); } 
}