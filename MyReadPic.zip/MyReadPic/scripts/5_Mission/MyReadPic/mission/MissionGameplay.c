modded class MissionGameplay 
{ override UIScriptedMenu CreateScriptedMenu(int id) 
{ UIScriptedMenu menu = super.CreateScriptedMenu(id); 
if (menu) return menu;

switch (id)
{
  case MYREADPIC_MENU_ID:
    return new PictureViewerMenu();
}

return null;
} 
}