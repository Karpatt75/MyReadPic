class CfgPatches 

    {  
	    class MyReadPic { 
		  units[] = {"MyPicturePaper"}; 
		  weapons[] = {}; 
		  requiredVersion = 0.1; 
		  requiredAddons[] = 
		    {
			  "DZ_Data",
			  "DZ_Scripts",
			  "DZ_Gear_Consumables"
		    }; 
	}; 
};

         class CfgMods 
		 { 
		 class MyReadPic 
		 { 
		 dir = "MyReadPic"; 
		 picture = ""; 
		 action = ""; 
		 hideName = 1; 
		 hidePicture = 1; 
		 name = "MyReadPic"; 
		 credits = ""; 
		 author = "you"; 
		 version = "1.0"; 
		 type = "mod"; 
		 dependencies[
		 ] 
		 =  {
			 "World",
			 "Mission"
			}; 
		 class defs 
		 { 
		 class worldScriptModule 
		 { value = ""; 
		 files[] = {"MyReadPic/scripts/4_World"}; 
		 }; 
		 class missionScriptModule 
		 { value = ""; 
		 files[] = {"MyReadPic/scripts/5_Mission"}; 
		 }; 
		 }; 
		 }; 
		 };

         class CfgVehicles 
		 { class Paper; 
		 class MyPicturePaper: Paper 
		 { 
		 scope = 2; 
		 displayName = "Картинка на бумаге"; 
		 descriptionShort = "Прочтите, чтобы увидеть изображение."; 
		 model = "\dz\gear\consumables\t_note.p3d"; // стандартная модель Paper // при желании можно задать другие параметры, коллизии и т.п. 
		 }; 
		 };